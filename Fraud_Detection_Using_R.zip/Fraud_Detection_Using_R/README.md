# Financial Transaction Fraud Detection Using R

## Project Overview
This project uses R programming to analyze financial transaction data and identify suspicious or fraudulent transaction patterns.

The analysis focuses on transaction amount, transaction time, location, account age, and fraud status.

## Objectives
- Analyze financial transaction data.
- Identify fraudulent and genuine transactions.
- Find unusual transaction amount patterns.
- Analyze transaction time patterns.
- Analyze account age associated with fraud.
- Identify locations with a high concentration of flagged transactions.
- Visualize fraud patterns.

## Dataset
- **Txn_ID** - Unique transaction ID
- **Amount** - Transaction amount
- **Time_Hour** - Hour of transaction
- **Location** - Transaction location
- **Account_Age** - Account age in days
- **Fraud_Flag** - Fraud status

## Technologies Used
- R Programming
- RStudio
- CSV Dataset
- Base R Visualization

## Data Analysis Process
Collect Transactions -> Clean Data -> Analyze Data -> Find Anomalies -> Visualize Results -> Flag Suspicious Transactions

## Data Preprocessing
Missing values and duplicate records are checked using:
- `is.na()`
- `na.omit()`
- `duplicated()`

## R Functions Used
`read.csv()`, `print()`, `mean()`, `table()`, `aggregate()`, `hist()`, `barplot()`

## Visualizations
1. Transaction Amount Distribution
2. Fraud Status
3. Location-wise Transaction Count
4. Fraudulent Transactions by Location
5. Transaction Time Distribution

## Project Structure
```text
Fraud_Detection_Using_R/
|
|-- fraud_detection.R
|-- fraud_dataset.csv
|-- README.md
|
`-- output/
    |-- transaction_amount_distribution.png
    |-- fraud_status.png
    |-- location_wise_transactions.png
    |-- fraud_by_location.png
    `-- transaction_time_distribution.png
```

## How to Run
1. Install R and RStudio.
2. Open `fraud_detection.R` in RStudio.
3. Keep `fraud_dataset.csv` in the same folder.
4. Run the complete R program.
5. View the results in the RStudio console.
6. Generated graphs are saved in the `output` folder.

## Expected Findings
The analysis can identify high-value fraudulent transactions, unusual transaction hours, newly created accounts associated with suspicious activity, and locations with a higher concentration of flagged transactions.

## Conclusion
Financial Transaction Fraud Detection using R provides an efficient method for analyzing transaction data through data cleaning, statistical analysis, frequency counting, anomaly identification, and visualization.
