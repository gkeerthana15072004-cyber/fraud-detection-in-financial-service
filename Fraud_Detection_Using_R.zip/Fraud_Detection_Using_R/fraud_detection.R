# Financial Transaction Fraud Detection Using R

data <- read.csv("fraud_dataset.csv")
print(data)

# Data preprocessing
print(colSums(is.na(data)))
clean_data <- na.omit(data)
print(duplicated(clean_data))
clean_data <- clean_data[!duplicated(clean_data), ]

# Basic analysis
average_amount <- mean(clean_data$Amount)
average_account_age <- mean(clean_data$Account_Age)
cat("Average Transaction Amount:", average_amount, "\n")
cat("Average Account Age:", average_account_age, "days\n")

print(table(clean_data$Fraud_Flag))
print(table(clean_data$Location))

# Fraud patterns
print(aggregate(Amount ~ Fraud_Flag, data=clean_data, mean))
print(aggregate(Account_Age ~ Fraud_Flag, data=clean_data, mean))

fraud_data <- clean_data[clean_data$Fraud_Flag=="Yes",]
print(table(fraud_data$Location))

night_fraud <- fraud_data[fraud_data$Time_Hour >= 0 & fraud_data$Time_Hour <= 3,]
print(night_fraud)

# Visualizations
if (!dir.exists("output")) dir.create("output")

png("output/transaction_amount_distribution.png",900,600)
hist(clean_data$Amount, main="Transaction Amount Distribution",
     xlab="Transaction Amount", ylab="Number of Transactions")
dev.off()

png("output/fraud_status.png",900,600)
barplot(table(clean_data$Fraud_Flag), main="Fraud Status",
        xlab="Fraud Flag", ylab="Number of Transactions")
dev.off()

png("output/location_wise_transactions.png",900,600)
barplot(table(clean_data$Location), main="Location-wise Transaction Count",
        xlab="Location", ylab="Number of Transactions")
dev.off()

png("output/fraud_by_location.png",900,600)
barplot(table(fraud_data$Location), main="Fraudulent Transactions by Location",
        xlab="Location", ylab="Number of Fraudulent Transactions")
dev.off()

png("output/transaction_time_distribution.png",900,600)
hist(clean_data$Time_Hour, breaks=seq(-0.5,23.5,1),
     main="Transaction Time Distribution",
     xlab="Transaction Hour", ylab="Number of Transactions")
dev.off()

fraud_count <- sum(clean_data$Fraud_Flag=="Yes")
cat("\nTotal Transactions:", nrow(clean_data), "\n")
cat("Fraudulent Transactions:", fraud_count, "\n")
cat("Fraud Percentage:", fraud_count/nrow(clean_data)*100, "%\n")
cat("\nAnalysis completed successfully.\n")
