# Student Performance Analysis Using R

## Use Case
This project analyzes student academic data to identify patterns related to study hours, attendance, assignment scores, and exam performance.

## Dataset
The dataset contains:
- Student ID
- Age
- Gender
- Study Hours
- Attendance
- Assignment Score
- Exam Marks
- Result

## R Concepts Used
- CSV data loading
- Data inspection with `str()` and `summary()`
- Missing-value handling using `na.omit()`
- Duplicate detection
- Mean calculation
- Frequency tables
- Aggregation
- Correlation analysis
- Histogram
- Bar plot
- Scatter plot

## How to Run
1. Open RStudio.
2. Keep `student_performance_analysis.R` and `student_performance.csv` in the same folder.
3. Set the RStudio working directory to that folder.
4. Run the complete R script.
5. Graphs will be generated inside the `output` folder.

## Output
The script generates:
- Exam marks distribution
- Student result distribution
- Attendance distribution
- Study hours vs exam marks
- Gender-wise performance

## Conclusion
The analysis helps identify relationships between study habits, attendance, and academic performance. These patterns can support data-driven academic monitoring and student support.
