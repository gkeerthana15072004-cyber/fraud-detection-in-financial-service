Run student_performance_analysis.R to generate the PNG charts in this folder.
