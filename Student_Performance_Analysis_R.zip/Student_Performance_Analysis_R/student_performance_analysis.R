# Student Performance Analysis Using R
# Real-world use case: identify patterns affecting student results

# -----------------------------
# 1. Create / Load Dataset
# -----------------------------
data <- read.csv("student_performance.csv")

print(data)

# -----------------------------
# 2. Basic Data Inspection
# -----------------------------
str(data)
summary(data)

# -----------------------------
# 3. Data Preprocessing
# -----------------------------
# Check missing values
print(colSums(is.na(data)))

# Remove rows with missing values, if any
clean_data <- na.omit(data)

# Check duplicate rows
print(duplicated(clean_data))

# Remove duplicate rows
clean_data <- clean_data[!duplicated(clean_data), ]

# -----------------------------
# 4. Statistical Analysis
# -----------------------------
average_age <- mean(clean_data$Age)
average_study_hours <- mean(clean_data$Study_Hours)
average_attendance <- mean(clean_data$Attendance)
average_exam_marks <- mean(clean_data$Exam_Marks)

cat("Average Age:", average_age, "\n")
cat("Average Study Hours:", average_study_hours, "\n")
cat("Average Attendance:", average_attendance, "\n")
cat("Average Exam Marks:", average_exam_marks, "\n")

# Pass / Fail count
print(table(clean_data$Result))

# Gender-wise result count
print(table(clean_data$Gender, clean_data$Result))

# -----------------------------
# 5. Find Performance Patterns
# -----------------------------
# Average exam marks by result
print(aggregate(Exam_Marks ~ Result, data = clean_data, mean))

# Average exam marks by gender
print(aggregate(Exam_Marks ~ Gender, data = clean_data, mean))

# Average marks by study hours
print(aggregate(Exam_Marks ~ Study_Hours, data = clean_data, mean))

# Correlation between study hours and exam marks
study_exam_correlation <- cor(clean_data$Study_Hours, clean_data$Exam_Marks)
cat("Study Hours vs Exam Marks Correlation:",
    study_exam_correlation, "\n")

# Correlation between attendance and exam marks
attendance_exam_correlation <- cor(clean_data$Attendance, clean_data$Exam_Marks)
cat("Attendance vs Exam Marks Correlation:",
    attendance_exam_correlation, "\n")

# -----------------------------
# 6. Visualizations
# -----------------------------

# Create output folder if it does not exist
if (!dir.exists("output")) {
  dir.create("output")
}

png("output/exam_marks_distribution.png", width=900, height=600)
hist(clean_data$Exam_Marks,
     main="Exam Marks Distribution",
     xlab="Exam Marks",
     ylab="Number of Students")
dev.off()

png("output/result_distribution.png", width=900, height=600)
barplot(table(clean_data$Result),
        main="Student Result Distribution",
        xlab="Result",
        ylab="Number of Students")
dev.off()

png("output/attendance_distribution.png", width=900, height=600)
hist(clean_data$Attendance,
     main="Attendance Distribution",
     xlab="Attendance (%)",
     ylab="Number of Students")
dev.off()

png("output/study_hours_vs_marks.png", width=900, height=600)
plot(clean_data$Study_Hours,
     clean_data$Exam_Marks,
     main="Study Hours vs Exam Marks",
     xlab="Study Hours",
     ylab="Exam Marks",
     pch=19)
abline(lm(Exam_Marks ~ Study_Hours, data=clean_data))
dev.off()

png("output/gender_wise_performance.png", width=900, height=600)
gender_avg <- aggregate(Exam_Marks ~ Gender, data=clean_data, mean)
barplot(gender_avg$Exam_Marks,
        names.arg=gender_avg$Gender,
        main="Gender-wise Average Exam Marks",
        xlab="Gender",
        ylab="Average Exam Marks")
dev.off()

# -----------------------------
# 7. Simple Findings
# -----------------------------
cat("\n--- FINDINGS ---\n")
cat("1. Average exam marks:", average_exam_marks, "\n")
cat("2. Average attendance:", average_attendance, "%\n")
cat("3. Average study hours:", average_study_hours, "\n")
cat("4. Study hours and exam marks correlation:",
    round(study_exam_correlation, 2), "\n")
cat("5. Attendance and exam marks correlation:",
    round(attendance_exam_correlation, 2), "\n")

cat("\nAnalysis completed successfully.\n")
